# rconfig
======================= LICENSE ===============================

rConfig is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

rConfig is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with rConfig.  If not, see <http://www.rConfig.com/license.txt/>.

======================= INSTALL ===============================

Guides can be found online at www.rConfig.com to help you through the installation
process. Check for the latest install guides in the support section

======================= BUG ===================================

Any bugs can be emailed directly. Send as much detail as possible to 
bugs@rconfig.com
