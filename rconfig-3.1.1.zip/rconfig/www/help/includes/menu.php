<HTML>
<HEAD>
<TITLE>Top Frame</TITLE>
</HEAD>
<BODY BGCOLOR="FFAADD">

Side menu

</BODY>
</HTML>