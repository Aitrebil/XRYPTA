<?php include("includes/head.inc.php"); ?>

<body>
	<div id="topNav">
		<table>
			<tr>
			<td><a href="#" class="active">Menu</a></td>
				<!-- <td><a href="navigate.php" class="active">Contents</a></td>
				<td><a href="navIndex.php">Index</a></td>
				<td><a href="navsearch.php">Search</a></td> -->
			</tr>
		</table>
	</div>