<?php include("includes/head.inc.php"); ?>

<body>
	<div id="topNav">
		<div id="imgs">
			<a href="1_introduction.php"><img src="images/home_48.png"></a>
			<a href="#" onclick="window.history.back()"><img src="images/arrow_left_48.png"></a>
			<a href="#" onclick="window.history.forward()"><img src="images/arrow_right_48.png"></a>
		</div>
	</div>
	