<?php include("includes/header.php"); ?>
 <frameset cols="200,*">
  <frame id="nav" name="nav" src="navigate.php" scrolling="no">
  <frame id="content" name="content" src="1_introduction.php" scrolling="auto">

  <noframes>
   <body>
    <p>This page uses frames, but your browser doesn't support them.</p>
   </body>
  </noframes>
 </frameset>
</html>
