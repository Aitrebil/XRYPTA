<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Version Notes</h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
			<p>
			Your have installed release <b><?php echo $config_version; ?></b> of <span class="rconfigNameStyle">rConfig</span>
			</p>
		<div class="break"></div>
			<p>
			You can see release notes for this version online at <a href="http://www.rconfig.com/releasenotes<?php echo $config_version; ?>.txt" target="_blank">www.rconfig.com/releasenotes<?php echo $config_version; ?>.txt</a>
			</p>
	</div>
</body>
</html>