<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Compliance Policy Elements</h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
			You should create single line Policy Elements on this page. The actual evaluation of the text entered here against the individual lines of a Configuration File is based on RegExp patterns. You are allowed ti use RegExp patterns in the input. You will have two choices available when entering a command. 'Equals' and 'Contains'. Where equals is an exact match of the inputted text and contains is any partial match.
		</p>
			<div class="break"></div>
		<p>
			Element Name and Element Description are mandatory fields for your convenience.
		</p>

	</div>
</body>
</html>
