<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Custom Properties</h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
			Add custom properties on this page to compliment the device addition process and search 
		</p>
		<p>
			<ul>
				<li>Custom Property - Mandatory Field - Aplhanumeric only</li>			
			</ul>
		</p>
		<p>
				Examples are: Site Name, Continent, Core, NetworkA, CustomerA etc...
		</p>
		<div class="break"></div>
	</div>
</body>
</html>