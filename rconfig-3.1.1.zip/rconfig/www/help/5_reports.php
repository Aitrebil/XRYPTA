<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Reports </h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
			The reports section is where you can view and download historical Connectivity Reports and Comparison Reports.  By clicking the 'Delete Reports' button, you can batch delete the saved reports
		</p>
		<div class="break"></div>
	</div>
</body>
</html>