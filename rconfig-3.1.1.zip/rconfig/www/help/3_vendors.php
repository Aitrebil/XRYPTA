<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Vendors</h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
		Add a vendor name and logo on this page to compliment the device addition process. 
		</p>
		<div class="break"></div>
		<p>
		Your allowed to add a Vendor name and logo
			<ul>
				<li>Vendor Name - Mandatory Field - Aplhanumeric only</li>
				<li>vendor Logo - Image - If none chosen, default logo used</li>
			</ul>
		</p>
	</div>
</body>
</html>