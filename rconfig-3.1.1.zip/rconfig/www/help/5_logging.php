<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Logging </h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
			Some rudementary logging is built into rConfig. The logging section allows you to view, archive, and delete these logs files. Mostly, these log file are used for support purposes. 
		</p>
		<div class="break"></div>
	</div>
</body>
</html>