<?php include("includes/head.main.inc.php"); ?>
	<div id="mainBanner">
		<div id="title">
			<h1>Backups</h1>
		</div>
	</div>
	<div id="mainContent">
		<div class="break"></div>
		<p>
		From this page you can create a full system backup. All folders, data, application files and database are backed up to a single ZIP file, which you can then download. <br/>You can also create a System Log Dump for support purposes.		</p>
		<div class="break"></div>
	</div> 
</body>
</html>