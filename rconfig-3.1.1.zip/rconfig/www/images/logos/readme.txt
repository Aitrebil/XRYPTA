Title: This is ART

Author:  Svengraph
             http://svengraph.deviantart.com/

License: Creative Commons Attribution 3.0 License.
             http://creativecommons.org/licenses/by/3.0/
